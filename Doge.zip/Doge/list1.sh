#!/bin/sh


ulang="y"

while [ $ulang = "y" ]
do
 python main.py +13152013039
 python main.py +13158171196
 python main.py +13159751796
 python main.py +13158954745
 python main.py +13157879527
 python main.py +13153162013
 python main.py +13159052725
 python main.py +13155046329
 python main.py +13155823780
 python main.py +13159678811
 python main.py +13156880890
 python main.py +13159052394
 python main.py +13153321955
 python main.py +13159462388
 python main.py +13156091886
 python main.py +16802040439
 python main.py +13157438751
 python main.py +13152886734
 python main.py +13156566302
 python main.py +13157453256
 python main.py +16802143978
 python main.py +16802040726
 python main.py +13159699977
 python main.py 
   
   
done
