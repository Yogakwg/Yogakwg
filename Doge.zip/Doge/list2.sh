#!/bin/sh


ulang="y"

while [ $ulang = "y" ]
do
 python main.py +13155434544
 python main.py +13158872357
 python main.py +13155039839
 python main.py +13156561817
 python main.py +13156441829
 python main.py +13152013383
 python main.py +13158872913
 python main.py +13152382781
 python main.py +13156566097
 python main.py +13159230472
 python main.py +13159150478
 python main.py +13157621902
 python main.py +13153142654
 python main.py +13157453446
 python main.py +13156162212
 python main.py +13156961327
 python main.py +13159235640
 python main.py +13159381596
 python main.py
    
    
done
