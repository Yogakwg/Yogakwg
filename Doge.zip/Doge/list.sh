#!/bin/sh


ulang="y"

while [ $ulang = "y" ]
do
 python main.py +6282236256031
 python main.py +6289527288643
 python main.py +13153339143
 python main.py +16802019290
 python main.py +13153718538
 python main.py +13159698689
 python main.py +13158697437
 python main.py +13155080228
 python main.py +13157451520
 python main.py +13152886585
 python main.py +13156093297
 python main.py +13155039976
 python main.py +13155221259
 python main.py +13159391030
 python main.py +13152021240
 python main.py +13153108754
 python main.py +13157144325
 python main.py +13157144913
 python main.py +13154652186
 python main.py +13152919373
 python main.py +13156291726
 python main.py +13153870596
 python main.py 
   
   
done
